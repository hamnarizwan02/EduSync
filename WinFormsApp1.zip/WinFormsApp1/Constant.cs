﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    internal class Constant
    {
        //hamna's
        public const string ConnectionString = "data source = LAPTOP-S1HUQ0ID\\SQLEXPRESS;database = LMS; integrated security = True";

        //kissa's
        //public const string ConnectionString = "Data Source=KISSASIUM\\SQLEXPRESS;database = edusync; Integrated Security=True";

        //arham's
        //public const string ConnectionString = "data source = DESKTOP-88SEP50\\SQLEXPRESS;database = EduSync; integrated security = True";
    }
}
